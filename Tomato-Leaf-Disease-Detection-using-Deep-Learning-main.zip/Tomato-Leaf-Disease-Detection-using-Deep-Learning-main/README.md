# Tomato-Leaf-Disease-Detection-using-Deep-Learning
Dataset is collected from Kaggle link
